import json
import unittest
import sys
import os

# 상위 디렉토리의 모듈을 import 할 수 있도록 경로 추가
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from lambda_function import lambda_handler

class TestLambdaFunction(unittest.TestCase):
    """Lambda 함수 테스트 클래스"""
    
    def test_lambda_handler(self):
        """기본 핸들러 함수 테스트"""
        # 테스트 이벤트 생성
        event = {
            'httpMethod': 'GET',
            'path': '/test',
            'headers': {
                'Content-Type': 'application/json'
            },
            'queryStringParameters': None,
            'body':  {
                'number': '1'
            }
        }
        
        # Lambda 함수 호출
        response = lambda_handler(event, None)
        
        # 응답 검증
        self.assertEqual(response['statusCode'], 200)
        body = json.loads(response['body'])
        self.assertEqual(body['message'], 'Hello from Lambda!')

if __name__ == '__main__':
    unittest.main()