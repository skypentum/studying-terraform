import json
from lambda_function import lambda_handler

def main():
    """
    로컬에서 Lambda 함수를 테스트하기 위한 메인 함수
    """
    # 테스트 이벤트 생성
    test_event = {
        'httpMethod': 'GET',
        'path': '/test',
        'headers': {
            'Content-Type': 'application/json'
        },
        'queryStringParameters': None,
        'body':  {
            'number': '1'
        }
    }
    
    # Lambda 함수 호출
    print("테스트 이벤트:", json.dumps(test_event, indent=2))
    response = lambda_handler(test_event, None)
    print("Lambda 응답:", json.dumps(response, indent=2))

if __name__ == "__main__":
    main()