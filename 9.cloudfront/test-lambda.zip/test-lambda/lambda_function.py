import json

def lambda_handler(event, context):
    """
    Lambda 함수의 메인 핸들러
    
    Parameters:
        event (dict): Lambda 함수에 전달된 이벤트 데이터
        context (LambdaContext): Lambda 함수의 런타임 정보
        
    Returns:
        dict: API Gateway에 반환할 응답
    """
    try:
        # 이벤트 데이터 처리
        print("Received event: " + json.dumps(event))
        
        # 비즈니스 로직 구현
        input_value = event.get('number') or 'none input'
        message = "Hello from Lambda!" + input_value

        
        # 응답 반환
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': message
            })
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Internal server error'
            })
        }