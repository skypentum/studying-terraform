# AWS Lambda 테스트 프로젝트

이 프로젝트는 AWS Lambda 함수를 개발하고 로컬에서 테스트하기 위한 기본 구조를 제공합니다.

## 프로젝트 구조

```
test-lambda/
├── .vscode/                  # VSCode 설정 파일
│   ├── launch.json           # 디버깅 설정
│   └── settings.json         # VSCode 설정
├── events/                   # 테스트 이벤트 파일
│   └── api_event.json        # API Gateway 이벤트 샘플
├── tests/                    # 테스트 코드
│   ├── __init__.py           # 테스트 패키지 초기화 파일
│   └── test_lambda_function.py # Lambda 함수 테스트
├── lambda_function.py        # Lambda 함수 코드
├── local_test.py             # 로컬 테스트 스크립트
├── requirements.txt          # 의존성 정의
├── samconfig.toml            # SAM CLI 설정
├── template.yaml             # SAM 템플릿
└── README.md                 # 프로젝트 설명
```

## 로컬에서 테스트하기

### 1. 가상 환경 설정

```bash
# 가상 환경 생성
python -m venv .venv

# 가상 환경 활성화 (Windows)
.venv\Scripts\activate

# 의존성 설치
pip install -r requirements.txt
```

### 2. 로컬에서 Lambda 함수 실행

```bash
# 로컬 테스트 스크립트 실행
python local_test.py
```

### 3. 단위 테스트 실행

```bash
# 모든 테스트 실행
python -m unittest discover -s tests
```

### 4. AWS SAM CLI를 사용한 로컬 테스트

```bash
# SAM CLI 설치 필요 (https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/serverless-sam-cli-install.html)

# 로컬에서 Lambda 함수 호출
sam local invoke TestFunction -e events/api_event.json

# 로컬에서 API Gateway 시작
sam local start-api
```

## VSCode에서 디버깅

1. VSCode에서 프로젝트 열기
2. 디버그 탭에서 "Debug Lambda Function" 선택
3. F5 키를 눌러 디버깅 시작

## AWS에 배포하기

```bash
# SAM CLI를 사용하여 배포
sam build
sam deploy --guided
```

## 참고

1) public.ecr.aws 로그인
aws ecr-public get-login-password --region us-east-1 --no-verify-ssl | docker login --username AWS --password-stdin public.ecr.aws/y5x9i6s6

2) sam local invoke TestFunction -e events/api_event.json 에러 발생 시, --skip-pull-image 옵션 추가
sam local invoke TestFunction -e events/api_event.json --skip-pull-image